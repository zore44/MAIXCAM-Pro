# ------------ 外部封装 ------------
from maix import image, camera, display, app, time,uart
import cv2
import numpy as np
from LAB_a import ColorThresholdConfig
from struct import pack

# 串口初始化
device = "/dev/ttyS0"
serial0 = uart.UART(device, 115200, uart.BITS.BITS_8,
                    uart.PARITY.PARITY_NONE,
                    uart.STOP.STOP_1)



def send_bytes(*ints16):
    """
    通过UART发送一组16位整数，自动添加起始和结束标志
    ints16: 8个16位整数（0 <= num <= 65535）
    """
    start_byte = 0xA5A5
    end_byte = 0x5B5B
    # 打包格式：H（起始字节） + 8H（8个坐标） + H（结束字节）
    format_str = ">H" + "H" * len(ints16) + "H"
    data = pack(format_str, start_byte, *ints16, end_byte)
    serial0.write(data)
    print("Sent data:", data)







config = ColorThresholdConfig()
threshold = config.run_threshold_adjust()   # 阻塞直到点 Exit

MIN_BLOB_AREA = 10          # 给色块用
MIN_RECT_AREA = 200         # 给矩形用
MAX_RECT_AREA = 8000000

def dian(img):
    blobs = img.find_blobs([threshold], merge=True)
    valid_blobs = [b for b in blobs if b.area() >= MIN_BLOB_AREA]
    if not valid_blobs:
        return None
    max_blob = max(valid_blobs, key=lambda b: b.area())
    # img.draw_rect(max_blob.x(), max_blob.y(), max_blob.w(), max_blob.h(),
    #               image.COLOR_GREEN)
    img.draw_cross(max_blob.cx(), max_blob.cy(), image.COLOR_GREEN, size=15,thickness=3)
    return max_blob

def sort_rect_points(pts):
    pts = sorted(pts, key=lambda p: (p[1], p[0]))
    top = sorted(pts[:2], key=lambda p: p[0])
    bottom = sorted(pts[2:], key=lambda p: p[0], reverse=True)
    return [top[0], top[1], bottom[0], bottom[1]]

def match_corners_by_distance(ref_pts, target_pts):
    matched = [None] * 4
    used = [False] * 4
    for i, p1 in enumerate(ref_pts):
        min_dist = float("inf")
        min_j = -1
        for j, p2 in enumerate(target_pts):
            if not used[j]:
                dist = np.linalg.norm(np.array(p1) - np.array(p2))
                if dist < min_dist:
                    min_dist, min_j = dist, j
        matched[i] = target_pts[min_j]
        used[min_j] = True
    return matched

def is_similar_rect(rect1, rect2, threshold=8, area_thresh=0.05):
    try:
        rect1, rect2 = sort_rect_points(rect1), sort_rect_points(rect2)
        avg_dist = np.mean([np.linalg.norm(np.array(p1) - np.array(p2))
                            for p1, p2 in zip(rect1, rect2)])
        area1 = cv2.contourArea(np.array(rect1, dtype=np.int32))
        area2 = cv2.contourArea(np.array(rect2, dtype=np.int32))
        area_diff_ratio = abs(area1 - area2) / max(area1, area2)
        return avg_dist < threshold and area_diff_ratio < area_thresh
    except Exception as e:
        print("矩形比较异常:", e)
        return False

def is_rectangle(approx):
    if approx is None or len(approx) != 4 or not cv2.isContourConvex(approx):
        return False
    pts = [point[0] for point in approx]

    def angle(p1, p2, p3):
        v1, v2 = np.array(p1) - np.array(p2), np.array(p3) - np.array(p2)
        norm1, norm2 = np.linalg.norm(v1), np.linalg.norm(v2)
        if norm1 == 0 or norm2 == 0:
            return 0
        cos_angle = np.clip(np.dot(v1, v2) / (norm1 * norm2), -1.0, 1.0)
        return np.arccos(cos_angle) * 180 / np.pi

    angles = [angle(pts[i - 1], pts[i], pts[(i + 1) % 4]) for i in range(4)]
    return all(80 < ang < 100 for ang in angles)

def _detect_and_print(img_raw):
    gray = cv2.cvtColor(img_raw, cv2.COLOR_BGR2GRAY)
    bin_img = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                    cv2.THRESH_BINARY, 11, 2)
    closed = cv2.morphologyEx(bin_img, cv2.MORPH_CLOSE,
                              cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))
    contours, _ = cv2.findContours(closed, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    rectangles = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if not (MIN_RECT_AREA <= area <= MAX_RECT_AREA):
            continue
        x, y, w, h = cv2.boundingRect(contour)
        margin = 1
        if x < margin or y < margin or x + w > img_raw.shape[1] - margin or y + h > img_raw.shape[0] - margin:
            continue
        approx = cv2.approxPolyDP(contour, 0.02 * cv2.arcLength(contour, True), True)
        if is_rectangle(approx):
            rect = [tuple(pt[0]) for pt in approx]
            if not any(is_similar_rect(rect, r) for r in rectangles):
                rectangles.append(rect)

        if len(rectangles) == 2:
            r1 = sort_rect_points(rectangles[0])
            r2_unsorted = sort_rect_points(rectangles[1])
            r2 = match_corners_by_distance(r1, r2_unsorted)

            # 去掉列表/括号，直接拆成 8 个独立变量
            p0x, p0y = (r1[0][0] + r2[0][0]) // 2, (r1[0][1] + r2[0][1]) // 2
            p1x, p1y = (r1[1][0] + r2[1][0]) // 2, (r1[1][1] + r2[1][1]) // 2
            p2x, p2y = (r1[2][0] + r2[2][0]) // 2, (r1[2][1] + r2[2][1]) // 2
            p3x, p3y = (r1[3][0] + r2[3][0]) // 2, (r1[3][1] + r2[3][1]) // 2

            
            send_bytes(p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y)

            # 仍然按原来方式画四个黄色点
            for x, y in ((p0x, p0y), (p1x, p1y), (p2x, p2y), (p3x, p3y)):
                cv2.circle(img_raw, (x, y), 5, (0, 255, 255), -1)


# ------------ 主循环 ------------
cam = camera.Camera(320, 240, fps=80)
disp = display.Display()


while not app.need_exit():
    img = cam.read()
    data = serial0.read()
    if data:
        command = data[0]
        print("Received data:", hex(command))


        if command == 0x31:
            img_raw = image.image2cv(img, copy=True)
            _detect_and_print(img_raw)
            
            img = image.cv2image(img_raw, copy=False)

        if command == 0x30:
            max_blob = dian(img)
            if max_blob:   
                send_bytes(max_blob.cx(),max_blob.cy())
    disp.show(img)
